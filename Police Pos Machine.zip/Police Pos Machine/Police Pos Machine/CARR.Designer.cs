﻿namespace Police_Pos_Machine
{
    partial class CARR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CARR));
            pictureBox1 = new PictureBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            label1 = new Label();
            checkBox1 = new CheckBox();
            label2 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            textBox2 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label9 = new Label();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(192, 255, 255);
            pictureBox1.Location = new Point(161, 116);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(690, 657);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.BackColor = Color.FromArgb(255, 192, 128);
            checkBox3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox3.Location = new Point(207, 261);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(275, 24);
            checkBox3.TabIndex = 4;
            checkBox3.Text = "Driving without insurance 3000 TK";
            checkBox3.UseVisualStyleBackColor = false;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.BackColor = Color.FromArgb(255, 192, 128);
            checkBox4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox4.Location = new Point(207, 316);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(211, 24);
            checkBox4.TabIndex = 5;
            checkBox4.Text = "Parking offences 3500 TK";
            checkBox4.UseVisualStyleBackColor = false;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.BackColor = Color.FromArgb(255, 192, 128);
            checkBox5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox5.Location = new Point(207, 431);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(227, 24);
            checkBox5.TabIndex = 6;
            checkBox5.Text = "Wrong side driving 5000 TK";
            checkBox5.UseVisualStyleBackColor = false;
            checkBox5.CheckedChanged += checkBox5_CheckedChanged;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.BackColor = Color.FromArgb(255, 192, 128);
            checkBox6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox6.Location = new Point(207, 495);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(256, 24);
            checkBox6.TabIndex = 7;
            checkBox6.Text = "Without driving license 7000 TK";
            checkBox6.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(255, 128, 0);
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(396, 165);
            label1.Name = "label1";
            label1.Size = new Size(168, 23);
            label1.TabIndex = 8;
            label1.Text = "Traffic Offense CAR";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.FromArgb(255, 192, 128);
            checkBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox1.Location = new Point(207, 372);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(173, 24);
            checkBox1.TabIndex = 9;
            checkBox1.Text = "Over Speed 4500 TK";
            checkBox1.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(255, 128, 128);
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(263, 629);
            label2.Name = "label2";
            label2.Size = new Size(147, 20);
            label2.TabIndex = 11;
            label2.Text = "Total Fine Amount :";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Info;
            textBox1.Location = new Point(248, 664);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(170, 27);
            textBox1.TabIndex = 12;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 128, 128);
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(362, 708);
            button1.Name = "button1";
            button1.Size = new Size(89, 29);
            button1.TabIndex = 13;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(255, 128, 128);
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(224, 708);
            button2.Name = "button2";
            button2.Size = new Size(69, 29);
            button2.TabIndex = 14;
            button2.Text = "BACK";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Info;
            textBox2.Location = new Point(695, 652);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(107, 27);
            textBox2.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(255, 128, 128);
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(584, 655);
            label4.Name = "label4";
            label4.Size = new Size(88, 20);
            label4.TabIndex = 21;
            label4.Text = "Case Num :";
            // 
            // textBox3
            // 
            textBox3.BackColor = SystemColors.Info;
            textBox3.Location = new Point(695, 601);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(107, 27);
            textBox3.TabIndex = 27;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.AntiqueWhite;
            label9.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(518, 602);
            label9.Name = "label9";
            label9.Size = new Size(154, 23);
            label9.TabIndex = 28;
            label9.Text = "Submission Date :";
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.Location = new Point(669, 165);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(123, 120);
            pictureBox2.TabIndex = 29;
            pictureBox2.TabStop = false;
            // 
            // CARR
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(1084, 868);
            Controls.Add(pictureBox2);
            Controls.Add(label9);
            Controls.Add(textBox3);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(checkBox1);
            Controls.Add(label1);
            Controls.Add(checkBox6);
            Controls.Add(checkBox5);
            Controls.Add(checkBox4);
            Controls.Add(checkBox3);
            Controls.Add(pictureBox1);
            Name = "CARR";
            Text = "CARR";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private Label label1;
        private CheckBox checkBox1;
        private Label label2;
        private TextBox textBox1;
        private Button button1;
        private Button button2;
        private TextBox textBox2;
        private Label label4;
        private TextBox textBox3;
        private Label label9;
        private PictureBox pictureBox2;
    }
}