﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Police_Pos_Machine
{
    public partial class CARR : Form
    {
        public CARR()
        {
            InitializeComponent();
        }

        private void CARR_Load(object sender, EventArgs e)
        {

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            types_of s = new types_of();
            s.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
