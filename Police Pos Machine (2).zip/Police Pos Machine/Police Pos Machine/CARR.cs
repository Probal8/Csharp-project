﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Police_Pos_Machine
{
    public partial class CARR : Form
    {
        public CARR()
        {
            InitializeComponent();
        }

        private void CARR_Load(object sender, EventArgs e)
        {
            checkBox3.Tag = 3000; // Fine for checkBox3
            checkBox4.Tag = 3500; // Fine for checkBox4
            checkBox1.Tag = 4500; // Fine for checkBox1
            checkBox5.Tag = 5000; // Fine for checkBox5
            checkBox6.Tag = 7000; // Fine for checkBox6

            // Attach a common CheckedChanged event handler to all checkboxes
            checkBox3.CheckedChanged += CheckBox_CheckedChanged;
            checkBox4.CheckedChanged += CheckBox_CheckedChanged;
            checkBox1.CheckedChanged += CheckBox_CheckedChanged;
            checkBox5.CheckedChanged += CheckBox_CheckedChanged;
            checkBox6.CheckedChanged += CheckBox_CheckedChanged;
        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            CalculateTotalFine();
        }
        private void CalculateTotalFine()
        {
            int totalFine = 0;

            if (checkBox3.Checked)
                totalFine += Convert.ToInt32(checkBox3.Tag);

            if (checkBox4.Checked)
                totalFine += Convert.ToInt32(checkBox4.Tag);

            if (checkBox1.Checked)
                totalFine += Convert.ToInt32(checkBox1.Tag);

            if (checkBox5.Checked)
                totalFine += Convert.ToInt32(checkBox5.Tag);

            if (checkBox6.Checked)
                totalFine += Convert.ToInt32(checkBox6.Tag);


            textBox1.Text = totalFine.ToString();

        }


        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            types_of s = new types_of();
            s.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            types_of s = new types_of();
            s.Show();
        }



        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int totalFine = 0;

            // Add the fine amounts for specific checkboxes if they are checked
            if (checkBox3.Checked)
            {
                totalFine += Convert.ToInt32(checkBox3.Tag);
            }
            if (checkBox4.Checked)
            {
                totalFine += Convert.ToInt32(checkBox4.Tag);
            }


            if (checkBox1.Checked)
            {
                totalFine += Convert.ToInt32(checkBox1.Tag);
            }

            if (checkBox5.Checked)
            {
                totalFine += Convert.ToInt32(checkBox5.Tag);
            }

            if (checkBox6.Checked)
            {
                totalFine += Convert.ToInt32(checkBox6.Tag);
            }

            // Display the total fine in the textbox
            textBox1.Text = totalFine.ToString();

        }

    }
}