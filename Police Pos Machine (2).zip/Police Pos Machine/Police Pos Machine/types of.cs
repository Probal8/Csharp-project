﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Police_Pos_Machine
{
    public partial class types_of : Form
    {
        public types_of()
        {
            InitializeComponent();

            comboBox1.Items.Add("BIKE");
            comboBox1.Items.Add("CAR");
            comboBox1.Items.Add("TRUCK");


        }

        private void types_of_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedRole = comboBox1.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedRole))
            {
                MessageBox.Show("Please select a role from the ComboBox.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (selectedRole == "BIKE")
            {
                Fine_Amoun s = new Fine_Amoun();
                s.Show();
                this.Hide();
            }
            else if (selectedRole == "CAR")
            {
                CARR  s = new CARR ();
                s.Show();
                this.Hide ();
            }
            else if (selectedRole == "TRUCK")
            {
                Truck s = new Truck();
                s.Show();
                this.Hide ();
            }
           
            else
            {
                MessageBox.Show("Unknown role selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 s = new Form1();
            s.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}







