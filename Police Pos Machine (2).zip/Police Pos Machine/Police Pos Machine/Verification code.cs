﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Police_Pos_Machine
{
    public partial class Verification_code : Form
    {
        public Verification_code()
        {
            InitializeComponent();
        }
    }
}
