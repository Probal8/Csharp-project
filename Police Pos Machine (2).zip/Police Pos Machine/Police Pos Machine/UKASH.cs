﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Police_Pos_Machine
{
    public partial class UKASH : Form
    {
        private string generatedCode;

        public UKASH()
        {
            InitializeComponent();
        }

        private void UKASH_Load(object sender, EventArgs e)
        {
            // Populate ComboBox with values
            comboBox1.Items.Add("1000");
            comboBox1.Items.Add("2000");
            comboBox1.Items.Add("2500");
            comboBox1.Items.Add("3000");
            comboBox1.Items.Add("3500");
            comboBox1.Items.Add("4500");
            comboBox1.Items.Add("5000");
            comboBox1.Items.Add("5500");
            comboBox1.Items.Add("6000");
            comboBox1.Items.Add("6500");
            comboBox1.Items.Add("7000");
            comboBox1.Items.Add("10000");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedAmount = comboBox1.SelectedItem?.ToString();
            string phoneNumber = textBox1.Text;


            if (string.IsNullOrEmpty(phoneNumber) || phoneNumber.Length != 11)
            {
                MessageBox.Show("Please enter a valid 11-digit phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (string.IsNullOrEmpty(selectedAmount))
            {
                MessageBox.Show("Please select a payment amount.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Generate verification code
            generatedCode = GenerateVerificationCode();
            MessageBox.Show($"A verification code has been sent to {phoneNumber}. Code: {generatedCode} (for testing purposes).",
                "Verification Code Sent", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Open the Verification form
            VerificationCode pinCodeForm = new VerificationCode();
            pinCodeForm.Show();
            this.Hide();
        }

        private string GenerateVerificationCode()
        {
            Random random = new Random();
            return random.Next(100000, 999999).ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Payment code = new Payment();
            code.Show();
            Hide();
        }
    }
}
