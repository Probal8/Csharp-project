﻿namespace Police_Pos_Machine
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Payment));
            pictureBox2 = new PictureBox();
            label7 = new Label();
            checkBox2 = new CheckBox();
            pictureBox3 = new PictureBox();
            checkBox1 = new CheckBox();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.Location = new Point(504, 27);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(124, 122);
            pictureBox2.TabIndex = 31;
            pictureBox2.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ActiveCaption;
            label7.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(210, 102);
            label7.Name = "label7";
            label7.Size = new Size(99, 24);
            label7.TabIndex = 32;
            label7.Text = "Payment";
            label7.Click += label7_Click;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = SystemColors.ActiveCaption;
            checkBox2.Location = new Point(344, 171);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(79, 24);
            checkBox2.TabIndex = 33;
            checkBox2.Text = "UCASH";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = (Image)resources.GetObject("pictureBox3.BackgroundImage");
            pictureBox3.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox3.Location = new Point(320, 212);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(125, 84);
            pictureBox3.TabIndex = 34;
            pictureBox3.TabStop = false;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = SystemColors.ActiveCaption;
            checkBox1.Location = new Point(87, 171);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(69, 24);
            checkBox1.TabIndex = 35;
            checkBox1.Text = "CASH";
            checkBox1.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Location = new Point(79, 212);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(84, 84);
            pictureBox1.TabIndex = 36;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Crimson;
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(504, 365);
            button1.Name = "button1";
            button1.Size = new Size(94, 37);
            button1.TabIndex = 37;
            button1.Text = "DONE";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Payment
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(665, 438);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(checkBox1);
            Controls.Add(pictureBox3);
            Controls.Add(checkBox2);
            Controls.Add(label7);
            Controls.Add(pictureBox2);
            Name = "Payment";
            Text = "Payment";
            Load += Payment_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox2;
        private Label label7;
        private CheckBox checkBox2;
        private PictureBox pictureBox3;
        private CheckBox checkBox1;
        private PictureBox pictureBox1;
        private Button button1;
    }
}