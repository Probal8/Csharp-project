namespace Police_Pos_Machine
{
    public partial class Form1 : Form
    {

        private readonly string validUsername = "admin";
        private readonly string validPassword = "12345@@@";
        public Form1()
        {

            InitializeComponent();


            comboBox1.Items.Add("Ayan");
            comboBox1.Items.Add("Probal");
            comboBox1.Items.Add("Moon");

            textBox2.PasswordChar = '*';

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;


            if (username == validUsername && password == validPassword)
            {

                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                types_of t = new types_of();
                t.Show();
            }
            else
            {

                MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Registration_form s = new Registration_form();
            s.Show();
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }
    }
}

